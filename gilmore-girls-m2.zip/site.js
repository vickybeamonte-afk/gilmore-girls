
document.addEventListener('DOMContentLoaded',()=>{
 const menu=document.querySelector('.global-menu'), drawer=document.querySelector('.global-drawer');
 const close=document.querySelector('.global-close');
 if(menu&&drawer){menu.addEventListener('click',()=>{drawer.classList.add('open');drawer.setAttribute('aria-hidden','false')});}
 if(close&&drawer){close.addEventListener('click',()=>{drawer.classList.remove('open');drawer.setAttribute('aria-hidden','true')});}
 const sb=document.querySelector('.global-search'), sp=document.querySelector('.global-search-panel'), sc=document.querySelector('.global-search-close');
 if(sb&&sp) sb.addEventListener('click',()=>{sp.classList.add('open');setTimeout(()=>sp.querySelector('input')?.focus(),30)});
 if(sc&&sp) sc.addEventListener('click',()=>sp.classList.remove('open'));
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){drawer?.classList.remove('open');sp?.classList.remove('open')}});
});

/* Visor universal: cada galería queda limitada a su propia sección. */
document.addEventListener('DOMContentLoaded',()=>{
  // Personajes y Collage ya tienen visores propios y cada página constituye su propia galería.
  if(document.body.classList.contains('page-personajes') || document.body.classList.contains('page-collage')) return;

  const allImages=[...document.querySelectorAll('main img')].filter(img=>
    !img.closest('.lightbox') && !img.closest('.site-image-lightbox') &&
    !img.classList.contains('search-symbol') && img.getAttribute('src')
  );
  if(!allImages.length) return;

  // El título grande de cada bloque vive dentro de un <section>. Por eso cada
  // imagen sólo navega entre las imágenes de su section más cercana.
  const groups=new Map();
  allImages.forEach(img=>{
    const section=img.closest('section') || img.closest('article') || img.parentElement;
    if(!groups.has(section)) groups.set(section,[]);
    groups.get(section).push(img);
  });

  const box=document.createElement('div');
  box.className='site-image-lightbox'; box.setAttribute('aria-hidden','true');
  box.innerHTML='<button class="site-lightbox-close" aria-label="Cerrar">×</button><button class="site-lightbox-arrow site-lightbox-prev" aria-label="Anterior">‹</button><img alt=""><div class="site-lightbox-caption"></div><button class="site-lightbox-arrow site-lightbox-next" aria-label="Siguiente">›</button>';
  document.body.appendChild(box);

  const big=box.querySelector('img'), caption=box.querySelector('.site-lightbox-caption');
  const prev=box.querySelector('.site-lightbox-prev'), next=box.querySelector('.site-lightbox-next');
  let activeImages=[], current=0;

  const show=i=>{
    if(!activeImages.length)return;
    current=(i+activeImages.length)%activeImages.length;
    big.src=activeImages[current].currentSrc||activeImages[current].src;
    big.alt=activeImages[current].alt||'';
    caption.textContent=activeImages[current].alt||'';
  };
  const open=(group,img)=>{
    activeImages=group;
    const multiple=activeImages.length>1;
    prev.style.display=multiple?'':'none';
    next.style.display=multiple?'':'none';
    show(Math.max(0,activeImages.indexOf(img)));
    box.classList.add('open');box.setAttribute('aria-hidden','false');document.body.classList.add('site-lightbox-open');
  };
  const close=()=>{box.classList.remove('open');box.setAttribute('aria-hidden','true');document.body.classList.remove('site-lightbox-open');activeImages=[];};

  groups.forEach(group=>group.forEach(img=>{
    img.dataset.siteLightbox='true';
    img.tabIndex=0;img.setAttribute('role','button');
    img.addEventListener('click',()=>open(group,img));
    img.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open(group,img)}});
  }));
  prev.onclick=e=>{e.stopPropagation();show(current-1)};
  next.onclick=e=>{e.stopPropagation();show(current+1)};
  box.querySelector('.site-lightbox-close').onclick=close;
  box.addEventListener('click',e=>{if(e.target===box)close()});
  document.addEventListener('keydown',e=>{if(!box.classList.contains('open'))return;if(e.key==='Escape')close();if(activeImages.length>1&&e.key==='ArrowLeft')show(current-1);if(activeImages.length>1&&e.key==='ArrowRight')show(current+1)});
});


/* Buscador global del website */
const GILMORE_SEARCH_INDEX = [{"page": "Inicio", "title": "Las chicas gilmore", "text": "Las chicas gilmore 2006 · 13+ · Drama Lorelai es una mamá soltera, independiente y tenaz. Su brillante hija Rory está destinada a grandes cosas. Juntas viven en un continuo debate agudo y apasionado. Elenco: Lauren Graham, Alexis Bledel y Scott Patterson Creadores: Amy Sherman-Palladino", "url": "../home/index.html#las-chicas-gilmore"}, {"page": "Inicio", "title": "Momentos más esperados", "text": "TE ACORDÁS DE... Momentos más esperados Temporada 7, Episodio 21 VER MÁS Temporada 3, Episodio 9 VER MÁS Temporada 5, Episodio 7 VER MÁS", "url": "../home/index.html#momentos-mas-esperados"}, {"page": "Inicio", "title": "¡Visitá el pueblo!", "text": "¡Visitá el pueblo! VER MÁS", "url": "../home/index.html#visita-el-pueblo"}, {"page": "Inicio", "title": "Los de siempre", "text": "PERSONAJES Los de siempre Lorelai Gilmore Luke Danes Lane Kim Sookie St. James Emily and Richard Gilmore Rory Gilmore", "url": "../home/index.html#los-de-siempre"}, {"page": "Inicio", "title": "Inicio", "text": "Las chicas gilmore 2006 · 13+ · Drama Lorelai es una mamá soltera, independiente y tenaz. Su brillante hija Rory está destinada a grandes cosas. Juntas viven en un continuo debate agudo y apasionado. Elenco: Lauren Graham, Alexis Bledel y Scott Patterson Creadores: Amy Sherman-Palladino TE ACORDÁS DE... Momentos más esperados Temporada 7, Episodio 21 VER MÁS Temporada 3, Episodio 9 VER MÁS Temporada 5, Episodio 7 VER MÁS ¡Visitá el pueblo! VER MÁS PERSONAJES Los de siempre Lorelai Gilmore Luke Danes Lane Kim Sookie St. James Emily and Richard Gilmore Rory Gilmore", "url": "../home/index.html"}, {"page": "Visitas", "title": "¡Convertite en una Gilmore!", "text": "¡Convertite en una Gilmore! VISITA EL PUEBLO", "url": "../visitas/index.html#convertite-en-una-gilmore"}, {"page": "Visitas", "title": "Cada 26 y 27 de Septiembre", "text": "EN BRIGHTON MI, ESTADOS UNIDOS Cada 26 y 27 de Septiembre", "url": "../visitas/index.html#cada-26-y-27-de-septiembre"}, {"page": "Visitas", "title": "Conocélos", "text": "Conocélos Conoce a tus personajes favoritos en un Meet and Greet dentro del pueblo de Stars Hollow. Disponibilidad actual con Luke y Kirk. VER MÁS", "url": "../visitas/index.html#conocelos"}, {"page": "Visitas", "title": "Visitas", "text": "¡Convertite en una Gilmore! VISITA EL PUEBLO EN BRIGHTON MI, ESTADOS UNIDOS Cada 26 y 27 de Septiembre Conocélos Conoce a tus personajes favoritos en un Meet and Greet dentro del pueblo de Stars Hollow. Disponibilidad actual con Luke y Kirk. VER MÁS", "url": "../visitas/index.html"}, {"page": "Personajes", "title": "Personajes", "text": "BREVES DESCRIPCIONES Personajes", "url": "../personajes/index.html#personajes"}, {"page": "Personajes", "title": "Personajes", "text": "BREVES DESCRIPCIONES Personajes", "url": "../personajes/index.html"}, {"page": "Contactos", "title": "¡Contactános!", "text": "¡Contactános!", "url": "../contactos/index.html#contactanos"}, {"page": "Contactos", "title": "Nuestro correo", "text": "Nuestro correo gilmores@gmail.com gilmorescontactanos@gmail.com", "url": "../contactos/index.html#nuestro-correo"}, {"page": "Contactos", "title": "Luke’s Cafe", "text": "Luke’s Cafe +1 (860) 555-0128", "url": "../contactos/index.html#luke-s-cafe"}, {"page": "Contactos", "title": "Atencion al cliente por Kirk", "text": "Atencion al cliente por Kirk +1 (860) 592-0156 kirks@gmail.com", "url": "../contactos/index.html#atencion-al-cliente-por-kirk"}, {"page": "Contactos", "title": "¿Algún mensaje urgente?", "text": "¿Algún mensaje urgente? CORREO TITULO DEL MENSAJE ENVIAR", "url": "../contactos/index.html#algun-mensaje-urgente"}, {"page": "Contactos", "title": "Contactos", "text": "¡Contactános! Nuestro correo gilmores@gmail.com gilmorescontactanos@gmail.com Luke’s Cafe +1 (860) 555-0128 Atencion al cliente por Kirk +1 (860) 592-0156 kirks@gmail.com ¿Algún mensaje urgente? CORREO TITULO DEL MENSAJE ENVIAR", "url": "../contactos/index.html"}, {"page": "Comunidad", "title": "Chatea con otros fans", "text": "BLOG Chatea con otros fans", "url": "../blog/index.html#chatea-con-otros-fans"}, {"page": "Comunidad", "title": "Comunidad", "text": "BLOG Chatea con otros fans ＋ FOTO PUBLICAR", "url": "../blog/index.html"}, {"page": "Temporadas", "title": "Las siete estaciones", "text": "Las siete estaciones Explora la evolución de Rory y Lorelai Gilmore a lo largo de la serie con sus episodios clave desde la temporada 1 a la 7.", "url": "../temporadas/index.html#las-siete-estaciones"}, {"page": "Temporadas", "title": "Episodios clave", "text": "TEMPORADAS Episodios clave TEMPORADA 1 TEMPORADA 1 TEMPORADA 2 TEMPORADA 3 TEMPORADA 4 TEMPORADA 5 TEMPORADA 6 TEMPORADA 7 Episodio 1 Lorelai recurre a regañadientes a sus padres en busca de ayuda económica después de que su hija Rory sea aceptada en una costosa escuela privada. Episodio 9 Lorelai convence a Rory de asistir a su primer baile en Chilton. Una nerviosa Rory le pide a Dean que la acompañe al evento, y Emily se autoinvita a casa de Lorelai. Episodio 21 Lorelai retoma su romance con Max y Luke se aleja de Rachel. Las mentiras de Tristin enfrentan a Paris y sus amigas con Rory.", "url": "../temporadas/index.html#episodios-clave"}, {"page": "Temporadas", "title": "Episodio 1", "text": "Episodio 1 Lorelai recurre a regañadientes a sus padres en busca de ayuda económica después de que su hija Rory sea aceptada en una costosa escuela privada.", "url": "../temporadas/index.html#episodio-1"}, {"page": "Temporadas", "title": "Episodio 9", "text": "Episodio 9 Lorelai convence a Rory de asistir a su primer baile en Chilton. Una nerviosa Rory le pide a Dean que la acompañe al evento, y Emily se autoinvita a casa de Lorelai.", "url": "../temporadas/index.html#episodio-9"}, {"page": "Temporadas", "title": "Episodio 21", "text": "Episodio 21 Lorelai retoma su romance con Max y Luke se aleja de Rachel. Las mentiras de Tristin enfrentan a Paris y sus amigas con Rory.", "url": "../temporadas/index.html#episodio-21"}, {"page": "Temporadas", "title": "Libros citados", "text": "REFERENCIAS Libros citados", "url": "../temporadas/index.html#libros-citados"}, {"page": "Temporadas", "title": "Banda sonora", "text": "NUESTROS FAVORITOS Banda sonora 1 Carole King - Where You Lead 3:21 Tapestry 2 The La's - There She Goes 2:51 The La's 3 Sam Philips - Reflecting Light 3:17 A Boot and a Shoe 4 Sam Philips - How to Dream 3:07 Fan Dance 5 Mazzy Star - Fade into You 4:55 So Tonight That I Might See", "url": "../temporadas/index.html#banda-sonora"}, {"page": "Temporadas", "title": "Temporadas", "text": "Las siete estaciones Explora la evolución de Rory y Lorelai Gilmore a lo largo de la serie con sus episodios clave desde la temporada 1 a la 7. Familia • Relaciones • Ambición • Romance • Pueblo • Amistad • Café TEMPORADAS Episodios clave TEMPORADA 1 TEMPORADA 1 TEMPORADA 2 TEMPORADA 3 TEMPORADA 4 TEMPORADA 5 TEMPORADA 6 TEMPORADA 7 Episodio 1 Lorelai recurre a regañadientes a sus padres en busca de ayuda económica después de que su hija Rory sea aceptada en una costosa escuela privada. Episodio 9 Lorelai convence a Rory de asistir a su primer baile en Chilton. Una nerviosa Rory le pide a Dean que la acompañe al evento, y Emily se autoinvita a casa de Lorelai. Episodio 21 Lorelai retoma su romance con Max y Luke se aleja de Rachel. Las mentiras de Tristin enfrentan a Paris y sus amigas con Rory. REFERENCIAS Libros citados NUESTROS FAVORITOS Banda sonora 1 Carole King - Where You Lead 3:21 Tapestry 2 The La's - There She Goes 2:51 The La's 3 Sam Philips - Reflecting Light 3:17 A Boot and a Shoe 4 Sam Philips - How to Dream 3:07 Fan Dance 5 Mazzy Star - Fade into You 4:55 So Tonight That I Might See", "url": "../temporadas/index.html"}, {"page": "Galería", "title": "Collage", "text": "Collage Recuerda tus momentos favoritos de la serie acompañados por risas.", "url": "../collage/index.html#collage"}, {"page": "Galería", "title": "Galería", "text": "Collage Recuerda tus momentos favoritos de la serie acompañados por risas.", "url": "../collage/index.html"},{"page": "Temporadas", "title": "Temporada 2 — Episodio 13", "text": "TEMPORADA 2 Episodio 13 Dean y Jess compiten por la cesta de Rory en una subasta. Jackson sorprende a Sookie con una propuesta durante la cena.", "url": "../temporadas/index.html?season=2#temporada-2-episodio-13"}, {"page": "Temporadas", "title": "Temporada 2 — Episodio 19", "text": "TEMPORADA 2 Episodio 19 Rory le da clases a Jess para evitar que suspenda el curso. Un descanso inesperado durante el estudio los lleva a urgencias.", "url": "../temporadas/index.html?season=2#temporada-2-episodio-19"}, {"page": "Temporadas", "title": "Temporada 2 — Episodio 22", "text": "TEMPORADA 2 Episodio 22 Christopher visita a Lorelai y la acompaña a la boda de Sookie. Rory se postula para la vicepresidencia de su clase en Chilton.", "url": "../temporadas/index.html?season=2#temporada-2-episodio-22"}, {"page": "Temporadas", "title": "Temporada 3 — Episodio 7", "text": "TEMPORADA 3 Episodio 7 Lorelai y Rory participan juntas en un maratón de baile. Rory no puede evitar mirar a Jess y Dean nota su distracción.", "url": "../temporadas/index.html?season=3#temporada-3-episodio-7"}, {"page": "Temporadas", "title": "Temporada 3 — Episodio 9", "text": "TEMPORADA 3 Episodio 9 Emily exige a las chicas asistir a la cena de Acción de Gracias. Lorelai descubre ahí que Rory solicitó su ingreso en Yale.", "url": "../temporadas/index.html?season=3#temporada-3-episodio-9"}, {"page": "Temporadas", "title": "Temporada 3 — Episodio 22", "text": "TEMPORADA 3 Episodio 22 Rory se gradúa y financia Yale para apoyar la posada de Lorelai. Luke evalúa un viaje con Nicole y preparan sus maletas a Europa.", "url": "../temporadas/index.html?season=3#temporada-3-episodio-22"}, {"page": "Temporadas", "title": "Temporada 4 — Episodio 22", "text": "TEMPORADA 4 Episodio 22 Jason intenta reconquistar a Lorelai y Rory busca acercarse a Dean. Lorelai intenta conciliar a sus padres con nefastos resultados.", "url": "../temporadas/index.html?season=4#temporada-4-episodio-22"}, {"page": "Temporadas", "title": "Temporada 4 — Episodio 4", "text": "TEMPORADA 4 Episodio 4 Rory ve a Dean antes de su boda y él la invita al evento. Lorelai visita a Michel mientras Luke escucha un dato incómodo.", "url": "../temporadas/index.html?season=4#temporada-4-episodio-4"}, {"page": "Temporadas", "title": "Temporada 4 — Episodio 6", "text": "TEMPORADA 4 Episodio 6 Lorelai atiende el evento de Richard, pero Emily acaba herida. En Yale, las compañeras de cuarto de Rory interrumpen su estudio.", "url": "../temporadas/index.html?season=4#temporada-4-episodio-6"}, {"page": "Temporadas", "title": "Temporada 5 — Episodio 7", "text": "TEMPORADA 5 Episodio 7 Luke conoce a los padres de Lorelai con tensas consecuencias. Rory investiga el club de Logan y Lane tiene su cita con Zack.", "url": "../temporadas/index.html?season=5#temporada-5-episodio-7"}, {"page": "Temporadas", "title": "Temporada 5 — Episodio 13", "text": "TEMPORADA 5 Episodio 13 Richard y Emily renuevan sus votos en una velada caótica. El festejo incluye una alocada fiesta previa y una gran pelea.", "url": "../temporadas/index.html?season=5#temporada-5-episodio-13"}, {"page": "Temporadas", "title": "Temporada 5 — Episodio 1", "text": "TEMPORADA 5 Episodio 1 Los sentimientos de Rory por Dean causan roces con su madre. Lorelai se acerca a Luke mientras Emily se distancia de Richard.", "url": "../temporadas/index.html?season=5#temporada-5-episodio-1"}, {"page": "Temporadas", "title": "Temporada 6 — Episodio 9", "text": "TEMPORADA 6 Episodio 9 Christopher altera a la pareja y Rory se muda con Lane. Luke ayuda en la feria y un mueble nuevo disgusta a Lorelai.", "url": "../temporadas/index.html?season=6#temporada-6-episodio-9"}, {"page": "Temporadas", "title": "Temporada 6 — Episodio 13", "text": "TEMPORADA 6 Episodio 13 Chris paga Yale y se reanudan las cenas de los viernes. Luke se descuida con April y renuncia el equipo del diario.", "url": "../temporadas/index.html?season=6#temporada-6-episodio-13"}, {"page": "Temporadas", "title": "Temporada 6 — Episodio 5", "text": "TEMPORADA 6 Episodio 5 Rory destaca en la DAR hasta la llegada de los Huntzberger. Lorelai va a un recital y Luke se siente marginado por ella.", "url": "../temporadas/index.html?season=6#temporada-6-episodio-5"}, {"page": "Temporadas", "title": "Temporada 7 — Episodio 20", "text": "TEMPORADA 7 Episodio 20 Rory teme al futuro y Lorelai canta para Luke en el karaoke. Logan vuelve de su viaje para hablar a solas con Lorelai.", "url": "../temporadas/index.html?season=7#temporada-7-episodio-20"}, {"page": "Temporadas", "title": "Temporada 7 — Episodio 21", "text": "TEMPORADA 7 Episodio 21 Richard y Emily celebran a Rory y Logan le da una sorpresa. Lorelai ve a Chris tras romper y Luke termina resentido.", "url": "../temporadas/index.html?season=7#temporada-7-episodio-21"}, {"page": "Temporadas", "title": "Temporada 7 — Episodio 22", "text": "TEMPORADA 7 Episodio 22 Rory consigue empleo y se prepara para dejar el pueblo. Luke organiza su despedida y Lorelai se le declara al fin.", "url": "../temporadas/index.html?season=7#temporada-7-episodio-22"}];
document.addEventListener('DOMContentLoaded',()=>{
  const wrap=document.querySelector('.global-search');
  if(!wrap || document.body.classList.contains('page-home')) return;
  const input=wrap.querySelector('.global-search-input');
  const submit=wrap.querySelector('.global-search-submit');
  const overlay=document.createElement('div');
  overlay.className='site-search-results';
  overlay.innerHTML='<div class="site-search-box"><button class="site-search-close" aria-label="Cerrar">×</button><div class="site-search-heading"></div><div class="site-search-list"></div></div>';
  document.body.appendChild(overlay);
  const list=overlay.querySelector('.site-search-list'), heading=overlay.querySelector('.site-search-heading');
  const normalize=s=>(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const run=()=>{
    const q=input.value.trim(); if(!q){input.focus();return;}
    const nq=normalize(q);
    const found=GILMORE_SEARCH_INDEX.filter(r=>normalize(r.title+' '+r.text).includes(nq));
    heading.textContent=found.length ? `Resultados para “${q}”` : `No encontramos “${q}”`;
    list.innerHTML='';
    const seen=new Set();
    found.forEach(r=>{
      const key=r.url; if(seen.has(key))return; seen.add(key);
      const a=document.createElement('a'); const sep=r.url.includes('?')?'&':'?'; const hashAt=r.url.indexOf('#'); let base=r.url, hash=''; if(hashAt>=0){base=r.url.slice(0,hashAt);hash=r.url.slice(hashAt);} a.href=base+(base.includes('?')?'&':'?')+'search='+encodeURIComponent(q)+hash; a.className='site-search-result';
      const t=document.createElement('strong'); t.textContent=r.title;
      const p=document.createElement('span'); p.textContent=r.page;
      const sn=document.createElement('small');
      const raw=r.text; const idx=normalize(raw).indexOf(nq); const start=Math.max(0,idx-65); sn.textContent=(start?'…':'')+raw.slice(start,start+180)+(raw.length>start+180?'…':'');
      a.append(t,p,sn); list.appendChild(a);
    });
    overlay.classList.add('open'); document.body.classList.add('site-search-open');
  };
  submit?.addEventListener('click',run);
  input?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();run();}});
  overlay.querySelector('.site-search-close').addEventListener('click',()=>{overlay.classList.remove('open');document.body.classList.remove('site-search-open')});
  overlay.addEventListener('click',e=>{if(e.target===overlay){overlay.classList.remove('open');document.body.classList.remove('site-search-open')}});
});


/* Lleva cada resultado al lugar exacto donde aparece la búsqueda. */
document.addEventListener('DOMContentLoaded',()=>{
  const params=new URLSearchParams(location.search);
  const q=params.get('search'); if(!q)return;
  const norm=v=>(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const focusMatch=()=>{
    const hashTarget=location.hash ? document.querySelector(location.hash) : null;
    const root=hashTarget?.closest('article,section') || hashTarget || document.querySelector('main') || document.body;
    const candidates=[...root.querySelectorAll('h1,h2,h3,h4,p,span,a,li,button')].filter(el=>{
      if(el.closest('.global-header,.global-drawer,.global-footer,.site-search-results')) return false;
      return norm(el.textContent).includes(norm(q));
    });
    const target=candidates.sort((a,b)=>a.textContent.length-b.textContent.length)[0] || hashTarget;
    if(target){target.classList.add('site-search-hit');target.scrollIntoView({behavior:'smooth',block:'center'});}
  };
  setTimeout(focusMatch, document.body.classList.contains('page-temporadas')?500:180);
});
