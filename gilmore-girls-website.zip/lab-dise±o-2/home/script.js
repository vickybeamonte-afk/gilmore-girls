const menu=document.querySelector('.menu');
menu.addEventListener('click',()=>{document.querySelector('footer').scrollIntoView({behavior:'smooth'});});
document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{const id=a.getAttribute('href');if(id.length>1){const el=document.querySelector(id);if(el){e.preventDefault();el.scrollIntoView({behavior:'smooth'});}}}));
