function bindNextButtons(){
  document.querySelectorAll('.rail-next').forEach(btn=>{
    const rail=document.getElementById(btn.dataset.rail);
    if(!rail)return;

    btn.addEventListener('click',()=>{
      const items=[...rail.children];
      if(!items.length)return;
      const gap=parseFloat(getComputedStyle(rail).gap)||0;
      const step=items[0].getBoundingClientRect().width+gap;
      const max=Math.max(0,rail.scrollWidth-rail.clientWidth);

      // Avanza exactamente una tarjeta hacia la izquierda para revelar la siguiente.
      // Al llegar al final, el siguiente click vuelve suavemente al comienzo.
      if(rail.scrollLeft>=max-4){
        rail.scrollTo({left:0,behavior:'smooth'});
      }else{
        rail.scrollTo({left:Math.min(rail.scrollLeft+step,max),behavior:'smooth'});
      }
    });
  });
}

bindNextButtons();

const seasonData = {
  1:[
    {ep:'Episodio 1',img:'assets/temp1-ep1.webp',text:'Lorelai recurre a regañadientes a sus padres en busca de ayuda económica después de que su hija Rory sea aceptada en una costosa escuela privada.'},
    {ep:'Episodio 9',img:'assets/temp1-ep9.webp',text:'Lorelai convence a Rory de asistir a su primer baile en Chilton. Una nerviosa Rory le pide a Dean que la acompañe al evento, y Emily se autoinvita a casa de Lorelai.'},
    {ep:'Episodio 21',img:'assets/temp1-ep21.webp',text:'Lorelai retoma su romance con Max y Luke se aleja de Rachel. Las mentiras de Tristin enfrentan a Paris y sus amigas con Rory.'}
  ],
  2:[
    {ep:'Episodio 13',img:'assets/temp2-ep13.webp',text:'Dean y Jess compiten por la cesta de Rory en una subasta. Jackson sorprende a Sookie con una propuesta durante la cena.'},
    {ep:'Episodio 19',img:'assets/temp2-ep19.webp',text:'Rory le da clases a Jess para evitar que suspenda el curso. Un descanso inesperado durante el estudio los lleva a urgencias.'},
    {ep:'Episodio 22',img:'assets/temp2-ep22.webp',text:'Christopher visita a Lorelai y la acompaña a la boda de Sookie. Rory se postula para la vicepresidencia de su clase en Chilton.'}
  ],
  3:[
    {ep:'Episodio 7',img:'assets/temp3-ep7.webp',text:'Lorelai y Rory participan juntas en un maratón de baile. Rory no puede evitar mirar a Jess y Dean nota su distracción.'},
    {ep:'Episodio 9',img:'assets/temp3-ep9.webp',text:'Emily exige a las chicas asistir a la cena de Acción de Gracias. Lorelai descubre ahí que Rory solicitó su ingreso en Yale.'},
    {ep:'Episodio 22',img:'assets/temp3-ep22.webp',text:'Rory se gradúa y financia Yale para apoyar la posada de Lorelai. Luke evalúa un viaje con Nicole y preparan sus maletas a Europa.'}
  ],
  4:[
    {ep:'Episodio 22',img:'assets/temp4-ep22.webp',text:'Jason intenta reconquistar a Lorelai y Rory busca acercarse a Dean. Lorelai intenta conciliar a sus padres con nefastos resultados.'},
    {ep:'Episodio 4',img:'assets/temp4-ep4.webp',text:'Rory ve a Dean antes de su boda y él la invita al evento. Lorelai visita a Michel mientras Luke escucha un dato incómodo.'},
    {ep:'Episodio 6',img:'assets/temp4-ep6.webp',text:'Lorelai atiende el evento de Richard, pero Emily acaba herida. En Yale, las compañeras de cuarto de Rory interrumpen su estudio.'}
  ],
  5:[
    {ep:'Episodio 7',img:'assets/temp5-ep7.webp',text:'Luke conoce a los padres de Lorelai con tensas consecuencias. Rory investiga el club de Logan y Lane tiene su cita con Zack.'},
    {ep:'Episodio 13',img:'assets/temp5-ep13.webp',text:'Richard y Emily renuevan sus votos en una velada caótica. El festejo incluye una alocada fiesta previa y una gran pelea.'},
    {ep:'Episodio 1',img:'assets/temp5-ep1.webp',text:'Los sentimientos de Rory por Dean causan roces con su madre. Lorelai se acerca a Luke mientras Emily se distancia de Richard.'}
  ],
  6:[
    {ep:'Episodio 9',img:'assets/temp6-ep9.webp',text:'Christopher altera a la pareja y Rory se muda con Lane. Luke ayuda en la feria y un mueble nuevo disgusta a Lorelai.'},
    {ep:'Episodio 13',img:'assets/temp6-ep13.webp',text:'Chris paga Yale y se reanudan las cenas de los viernes. Luke se descuida con April y renuncia el equipo del diario.'},
    {ep:'Episodio 5',img:'assets/temp6-ep5.webp',text:'Rory destaca en la DAR hasta la llegada de los Huntzberger. Lorelai va a un recital y Luke se siente marginado por ella.'}
  ],
  7:[
    {ep:'Episodio 20',img:'assets/temp7-ep20.webp',text:'Rory teme al futuro y Lorelai canta para Luke en el karaoke. Logan vuelve de su viaje para hablar a solas con Lorelai.'},
    {ep:'Episodio 21',img:'assets/temp7-ep21.webp',text:'Richard y Emily celebran a Rory y Logan le da una sorpresa. Lorelai ve a Chris tras romper y Luke termina resentido.'},
    {ep:'Episodio 22',img:'assets/temp7-ep22.webp',text:'Rory consigue empleo y se prepara para dejar el pueblo. Luke organiza su despedida y Lorelai se le declara al fin.'}
  ]
};

const seasonPicker=document.getElementById('seasonPicker');
const seasonButton=document.getElementById('seasonButton');
const seasonLabel=document.getElementById('seasonLabel');
const seasonMenu=document.getElementById('seasonMenu');
const episodesRail=document.getElementById('episodesRail');

function renderSeason(n){
  const data=seasonData[n]; if(!data)return;
  episodesRail.classList.add('changing');
  setTimeout(()=>{
    episodesRail.innerHTML=data.map(item=>{const epNum=(item.ep.match(/\d+/)||[''])[0];return `<article class="card" id="temporada-${n}-episodio-${epNum}"><img src="${item.img}" alt="${item.ep}"><h3>${item.ep.toUpperCase()}</h3><p>${item.text}</p></article>`}).join('');
    episodesRail.scrollTo({left:0,behavior:'auto'});
    seasonLabel.textContent=`TEMPORADA ${n}`;
    seasonMenu.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.season===String(n)));
    episodesRail.classList.remove('changing');
    seasonPicker.classList.remove('open');
    seasonButton.setAttribute('aria-expanded','false');
  },150);
}
seasonMenu.addEventListener('click',e=>{const b=e.target.closest('[data-season]');if(b)renderSeason(b.dataset.season)});
seasonButton.addEventListener('click',()=>{const open=seasonPicker.classList.toggle('open');seasonButton.setAttribute('aria-expanded',String(open))});
document.addEventListener('click',e=>{if(!seasonPicker.contains(e.target)){seasonPicker.classList.remove('open');seasonButton.setAttribute('aria-expanded','false')}});
const pageParams=new URLSearchParams(location.search);
const requestedSeason=Number(pageParams.get('season'))||1;
const requestedEpisode=Number(pageParams.get('episode'))||0;

renderSeason(requestedSeason);

// Cuando se llega desde "Momentos más esperados", la temporada se renderiza
// dinámicamente. Esperamos a que exista la tarjeta y desplazamos la página
// directamente al episodio correspondiente.
if(requestedEpisode){
  const targetId=`temporada-${requestedSeason}-episodio-${requestedEpisode}`;
  let attempts=0;
  const goToEpisode=()=>{
    const target=document.getElementById(targetId);
    if(target){
      target.scrollIntoView({behavior:'smooth',block:'center',inline:'center'});
      target.classList.add('episode-arrival');
      setTimeout(()=>target.classList.remove('episode-arrival'),1800);
      return;
    }
    if(attempts++<20)setTimeout(goToEpisode,100);
  };
  setTimeout(goToEpisode,220);
}
