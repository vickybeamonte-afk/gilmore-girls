document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contactForm");
  const status = document.getElementById("formStatus");
  if (!form || !status) return;
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    event.stopPropagation();
    status.textContent = "¡Enviado! 💌";
    status.classList.add("visible");
    form.reset();
    setTimeout(() => { status.classList.remove("visible"); }, 3500);
  });
});
