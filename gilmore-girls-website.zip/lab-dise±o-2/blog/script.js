const seed=[
['orange','ADORO  a Jess Mariano en la ultima temporada! Fue su mejor version',102,23],
['red','Todavia no vi la pelicula de Gilmore pero la verdad es que estoy muy emocionada por verla!',33,5],
['tan','Chicas AMO este website. Tiene todo lo que alguna vez necesite de Gilmore Girls. Es mi lugar seguro.',78,9],
['purple','Rory es mi ejemplo a seguir. No entienden lo mucho que me hizo crecer esta serie.',222,65,'assets/rory-blog.jpg'],
['yellow','AMO GILMORE GIRLS!!!',140,55]
];
const colors={orange:'#e8ad67',red:'#ff585d',tan:'#bf9986',purple:'#92649a',yellow:'#ffd24d',blue:'#4059a4'};
const feed=document.querySelector('#feed');let selected=null;
function renderPost(p,prepend=false){const el=document.createElement('article');el.className='post';el.innerHTML=`<div class="avatar" style="background:${colors[p[0]]||p[0]}"></div><p class="post-text"></p>${p[4]?`<img class="post-image" src="${p[4]}" alt="Imagen del comentario">`:''}<div class="post-actions"><button class="icon-btn like" aria-label="Me gusta">♡ <span>${p[2]}</span></button><button class="icon-btn send" aria-label="Enviar"><b class="send-icon">➤</b><span>${p[3]}</span></button></div>`;el.querySelector('.post-text').textContent=p[1];el.querySelector('.like').onclick=e=>{const b=e.currentTarget,n=b.querySelector('span');const on=b.classList.toggle('liked');b.firstChild.textContent=on?'♥ ':'♡ ';n.textContent=+n.textContent+(on?1:-1)};el.querySelector('.send').onclick=e=>{const n=e.currentTarget.querySelector('span');n.textContent=+n.textContent+1;if(navigator.share)navigator.share({title:'Gilmore´s Blog',text:p[1]}).catch(()=>{});else navigator.clipboard?.writeText(p[1])};prepend?feed.prepend(el):feed.append(el)}
seed.forEach(p=>renderPost(p));
photoInput.onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader;r.onload=()=>{selected=r.result;preview.innerHTML=`<img src="${selected}" alt="Vista previa">`};r.readAsDataURL(f)};
publish.onclick=()=>{const t=postText.value.trim();if(!t&&!selected)return;renderPost(['blue',t||'Foto compartida',0,0,selected],true);postText.value='';selected=null;preview.innerHTML='';photoInput.value='';};
