const characters=[
['Lorelai Gilmore','assets/lorelai.webp','Lorelai Gilmore es un personaje principal de “Gilmore Girls”. Es interpretada por Lauren Graham.'],
['Rory Gilmore','assets/rory.jpg','Rory Gilmore es una de las dos protagonistas de “Gilmore Girls”. Es interpretada por Alexis Bledel.'],
['Sookie St.James','assets/sookie.jpg','Interpretada por Melissa McCarthy.'],
['Lane Kim','assets/lane.jpg','Interpretada por Keiko Agena.'],
['Michele Gerard','assets/michele.jpg','Interpretado por Yanic Truesdale.'],
['Luke Danes','assets/luke.jpg','Interpretado por Scott Patterson.'],
['Emily y Richard Gilmore','assets/emily-richard.jpg','Interpretados por Kelly Bishop y Edward Herrmann.'],
['Dean Forester','assets/dean.jpg','Fue interpretado por Jared Padalecki.'],
['Jess Mariano','assets/jess.jpg','Interpretado por Milo Ventimiglia.'],
['Paris Geller','assets/paris.jpg','Interpretada por Liza Weil.']];
const grid=document.querySelector('#characters');characters.forEach(([name,img,desc])=>{const card=document.createElement('article');card.className='card';card.innerHTML=`<div class="photo"><img src="${img}" alt="${name}"></div><h2>${name}</h2><p>${desc}</p>`;grid.appendChild(card)});


// Visor ampliado con navegación, igual al sistema del collage.
const lightbox = document.querySelector('#lightbox');
const lightboxImage = lightbox.querySelector('.lightbox-image');
const lightboxCaption = lightbox.querySelector('.lightbox-caption');
let currentPhoto = 0;

function showPhoto(index) {
  currentPhoto = (index + characters.length) % characters.length;
  const [name, img] = characters[currentPhoto];
  lightboxImage.src = img;
  lightboxImage.alt = name;
  lightboxCaption.textContent = name;
}

function openLightbox(index) {
  showPhoto(index);
  lightbox.classList.add('open');
  lightbox.setAttribute('aria-hidden', 'false');
  document.body.classList.add('lightbox-open');
}

function closeLightbox() {
  lightbox.classList.remove('open');
  lightbox.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('lightbox-open');
}

document.querySelectorAll('.photo').forEach((photo, index) => {
  photo.setAttribute('role', 'button');
  photo.setAttribute('tabindex', '0');
  photo.setAttribute('aria-label', `Ver foto de ${characters[index][0]} en grande`);
  photo.addEventListener('click', () => openLightbox(index));
  photo.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openLightbox(index); }
  });
});

lightbox.querySelector('.lightbox-prev').addEventListener('click', e => { e.stopPropagation(); showPhoto(currentPhoto - 1); });
lightbox.querySelector('.lightbox-next').addEventListener('click', e => { e.stopPropagation(); showPhoto(currentPhoto + 1); });
lightbox.querySelector('.lightbox-close').addEventListener('click', closeLightbox);
lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });

document.addEventListener('keydown', e => {
  if (!lightbox.classList.contains('open')) return;
  if (e.key === 'Escape') closeLightbox();
  if (e.key === 'ArrowLeft') showPhoto(currentPhoto - 1);
  if (e.key === 'ArrowRight') showPhoto(currentPhoto + 1);
});
